from search import search, title_length, article_count, random_article, favorite_article, multiple_keywords, display_result
from search_tests_helper import get_print, print_basic, print_advanced, print_advanced_option
from wiki import article_titles
from unittest.mock import patch
from unittest import TestCase, main

class TestSearch(TestCase):

    ##############
    # UNIT TESTS #
    ##############

    def test_example_unit_test(self):
        # Storing into a variable so don't need to copy and paste long list every time
        # If you want to store search results into a variable like this, make sure you pass a copy of it when
        # calling a function, otherwise the original list (ie the one stored in your variable) might be
        # mutated. To make a copy, you may use the .copy() function for the variable holding your search result.
        expected_dog_search_results = ['Edogawa, Tokyo', 'Kevin Cadogan', 'Endogenous cannabinoid', 'Black dog (ghost)', '2007 Bulldogs RLFC season', 'Mexican dog-faced bat', 'Dalmatian (dog)', 'Guide dog', '2009 Louisiana Tech Bulldogs football team', 'Georgia Bulldogs football', 'Endoglin', 'Sun dog', 'The Mandogs', 'Georgia Bulldogs football under Robert Winston', 'Landseer (dog)']
        self.assertEqual(search('dog'), expected_dog_search_results) 
    def test_search_basic(self):
        self.assertEqual(search('fisk'), ['Fiskerton, Lincolnshire', 'Fisk University'])
        self.assertEqual(search('spain'), ['Spain national beach soccer team'])
        self.assertEqual(search('life'), ['Wildlife photography'])
        self.assertEqual(search('hope'), [])               
    def test_article_count_basic(self):
        self.assertEqual(article_count(5, search('dog')), ['Edogawa, Tokyo', 'Kevin Cadogan', 'Endogenous cannabinoid', 'Black dog (ghost)', '2007 Bulldogs RLFC season'])
        self.assertEqual(article_count(1, search('value')), ['Medical value travel'])
        self.assertEqual(article_count(3, search('life')), ['Wildlife photography'])
        self.assertEqual(article_count(4, search('computer')), ['Ken Kennedy (computer scientist)', 'Human computer', 'Single-board computer', 'Covariance and contravariance (computer science)'])
    def test_title_length(self):
        self.assertEqual(title_length(12, search('dog')), ['Guide dog', 'Endoglin', 'Sun dog', 'The Mandogs'])
        self.assertEqual(title_length(20, search('fisk')), ['Fisk University'])
        self.assertEqual(title_length(15, search('me')), ['Old-time music', 'Time travel'])
        self.assertEqual(title_length(14, search('land')), ['Landseer (dog)'])

    def test_random_article_basic(self):
        self.assertEqual(random_article(3, search('medical')), '')
        self.assertEqual(random_article(5, search('dog')), 'Mexican dog-faced bat')
        self.assertEqual(random_article(1, search('time')), 'Time travel')
        self.assertEqual(random_article(0, search('rock')), 'Rock music')
    def test_multiple_keywords_basic(self):
        self.assertEqual(multiple_keywords('rock', search('fisk')), ['Fiskerton, Lincolnshire', 'Fisk University', 'Rock music'])
        self.assertEqual(multiple_keywords('aube', search('soul')), ['List of soul musicians', 'Aube (musician)'])
        self.assertEqual(multiple_keywords('volleyball', search('ghost')),  ['Black dog (ghost)', 'USC Trojans volleyball', 'Mets de Guaynabo (volleyball)'])
    def test_favorite_article_basic(self):
        self.assertEqual(favorite_article('The Mandogs', search('dog')), True) 
        self.assertEqual(favorite_article('Fiskerton, Lincolnshire', search('fisk')), True) 
        self.assertEqual(favorite_article('drake', search('canadian')), False) 
        self.assertEqual(favorite_article('2007 in music', search('music')), True) 
        self.assertEqual(favorite_article('Project in Python', search('python')), False ) 
        self.assertEqual(favorite_article(' ', search('dog')), False)  
    def test_search_empty(self):
        expected = []
        output = search("")
        self.assertEqual(output, expected)
    def test_search_case_insensitive(self):
        expected = ['Python (programming language)']
        output = search("PYTHON")
        self.assertEqual(output, expected)    

    #####################
    # INTEGRATION TESTS #
    #####################

    @patch('builtins.input')
    def test_example_integration_test(self, input_mock):
        keyword = 'dog'
        advanced_option = 6

        # Output of calling display_results() with given user input. If a different
        # advanced option is included, append further user input to this list (after `advanced_option`)
        output = get_print(input_mock, [keyword, advanced_option])
        # Expected print outs from running display_results() with above user input
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "\nHere are your articles: ['Edogawa, Tokyo', 'Kevin Cadogan', 'Endogenous cannabinoid', 'Black dog (ghost)', '2007 Bulldogs RLFC season', 'Mexican dog-faced bat', 'Dalmatian (dog)', 'Guide dog', '2009 Louisiana Tech Bulldogs football team', 'Georgia Bulldogs football', 'Endoglin', 'Sun dog', 'The Mandogs', 'Georgia Bulldogs football under Robert Winston', 'Landseer (dog)']\n"

        # Test whether calling display_results() with given user input equals expected printout
        self.assertEqual(output, expected)

    @patch('builtins.input')
    def test_article_count(self, input_mock):
        keyword = 'music'
        advanced_option = 2

        # Output of calling display_results() with given user input. If a different
        # advanced option is included, appemuscnd further user input to this list (after `advanced_option`)
        output = get_print(input_mock, [keyword, advanced_option, 11])
        # Expected print outs from running display_results() with above user input
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "11\n\nHere are your articles: ['List of Canadian musicians', 'French pop music', 'Noise (music)', '1922 in music', '1986 in music', '2009 in music', 'Rock music', 'Lights (musician)', 'List of soul musicians', 'Aube (musician)', 'List of overtone musicians']\n"

        # Test whether calling display_results() with given user input equals expected printout
        self.assertEqual(output, expected)

    @patch('builtins.input')
    def test_title_length(self, input_mock):
        keyword = 'me'
        advanced_option = 1

        # Output of calling display_results() with given user input. If a different
        # advanced option is included, append further user input to this list (after `advanced_option`)
        output = get_print(input_mock, [keyword, advanced_option, 20])
        # Expected print outs from running display_results() with above user input
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "20\n\nHere are your articles: ['Medical value travel', 'Old-time music', 'Time travel']\n"

        # Test whether calling display_results() with given user input equals expected printout
        self.assertEqual(output, expected)

    @patch('builtins.input')
    def test_favorite_article(self, input_mock):
        keyword = 'sharp'
        advanced_option = 4
        # Output of calling display_results() with given user input. If a different
        # advanced option is included, append further user input to this list (after `advanced_option`)
        output = get_print(input_mock, [keyword, advanced_option, 'c sharp'])
        # Expected print outs from running display_results() with above user input
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "'c sharp'\n\nHere are your articles: ['C Sharp (programming language)']\nYour favorite article is in the returned articles!\n"
        # Test whether calling display_results() with given user input equals expected printout
        self.assertEqual(output, expected)

    @patch('builtins.input')
    def test_favorite_article(self, input_mock):
        keyword = 'fisk'
        advanced_option = 4
        # Output of calling display_results() with given user input. If a different
        # advanced option is included, append further user input to this list (after `advanced_option`)
        output = get_print(input_mock, [keyword, advanced_option, 'university'])
        # Expected print outs from running display_results() with above user input
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "university\n\nHere are your articles: ['Fiskerton, Lincolnshire', 'Fisk University']\nYour favorite article is not in the returned articles!\n"
        # Test whether calling display_results() with given user input equals expected printout
        self.assertEqual(output, expected)

    @patch('builtins.input') 
    def test_none(self, input_mock):
        keyword = 'noise'
        advanced_option = 6
        # Output of calling display_results() with given user input. If a different
        # advanced option is included, append further user input to this list (after `advanced_option`)
        output = get_print(input_mock, [keyword, advanced_option])
        # Expected print outs from running display_results() with above user input
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "\nHere are your articles: ['Noise (music)']\n"
        # Test whether calling display_results() with given user input equals expected printout
        self.assertEqual(output, expected) 

    @patch('builtins.input')             
    def test_random_article(self, input_mock):
        keyword = 'programming'
        advanced_option = 3
        # Output of calling display_results() with given user input. If a different
        # advanced option is included, append further user input to this list (after `advanced_option`)
        output = get_print(input_mock, [keyword, advanced_option, 7])
        # Expected print outs from running display_results() with above user input
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "7\n\nHere are your articles: Semaphore (programming)\n"

        self.assertEqual(output, expected)                        


# Write tests above this line. Do not remove.
if __name__ == "__main__":
    main()
