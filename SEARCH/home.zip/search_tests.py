from search import search, article_length, unique_authors, most_recent_article, favorite_author, title_and_author, refine_search, display_result
from search_tests_helper import get_print, print_basic, print_advanced, print_advanced_option
from wiki import article_metadata
from unittest.mock import patch
from unittest import TestCase, main

class TestSearch(TestCase):

    # #############
    # UNIT TESTS #
    # #############

    def test_example_unit_test(self):
        expected_search_soccer_results = [
            ['Spain national beach soccer team', 'jack johnson', 1233458894, 1526],
            ['Will Johnson (soccer)', 'Burna Boy', 1218489712, 3562],
            ['Steven Cohen (soccer)', 'Mack Johnson', 1237669593, 2117]
        ]
        self.assertEqual(search('soccer'), expected_search_soccer_results)
    def test_search(self):
        self.assertEqual(search('fisk'), [['Fisk University', 'RussBot', 1263393671, 16246]]) 
        self.assertEqual(search(' '), [])  
        self.assertEqual(search('ME'), [])
        self.assertEqual(search('10'), [])
        self.assertEqual(search('DoG'), [['Black dog (ghost)', 'Pegship', 1220471117, 14746], ['Mexican dog-faced bat', 'Mack Johnson', 1255316429, 1138], ['Dalmatian (dog)', 'Mr Jake', 1207793294, 26582], ['Guide dog', 'Jack Johnson', 1165601603, 7339], ['Sun dog', 'Mr Jake', 1208969289, 18050]])

    def test_article_length(self):
        self.assertEqual(article_length(5000, search('school')), [['Edogawa, Tokyo', 'jack johnson', 1222607041, 4526]])
        self.assertEqual(article_length(15000, search('bOOk')), [['List of dystopian music, TV programs, and games', 'Bearcat', 1165317338, 13458]])
        self.assertEqual(article_length(20000, search('fIsk')), [['Fisk University', 'RussBot', 1263393671, 16246]])
        self.assertEqual(article_length(0, search('Book')), [])
    def test_unique_authors(self):
        self.assertEqual(unique_authors(3, search('fISk')), [['Fisk University', 'RussBot', 1263393671, 16246]]) 
        self.assertEqual(unique_authors(2, search('dog')), [['Black dog (ghost)', 'Pegship', 1220471117, 14746], ['Mexican dog-faced bat', 'Mack Johnson', 1255316429, 1138]])
        self.assertEqual(unique_authors(2, search('the')), [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['French pop music', 'Mack Johnson', 1172208041, 5569]])
        self.assertEqual(unique_authors(0, search('Dog')), [])
    def test_most_recent_article(self):
        self.assertEqual(most_recent_article(search('musIc')), ['Rock music', 'Mack Johnson', 1258069053, 119498])
        self.assertEqual(most_recent_article(search('alL')), ["Wake Forest Demon Deacons men's soccer", 'Burna Boy', 1260577388, 26745])
        self.assertEqual(most_recent_article(search('mAn')), ['Black dog (ghost)', 'Pegship', 1220471117, 14746])
        self.assertEqual(most_recent_article(search('  ')), [])
    def test_favorite_author(self):
        self.assertEqual(favorite_author('JACK JOHNSON', search('soccer')), True)  
        self.assertEqual(favorite_author('RuSsBoT', search('FISK')), True)  
        self.assertEqual(favorite_author('burNa BOy', search('lisT')), True)    
        self.assertEqual(favorite_author('DrAKe', search('DoG')), False)
        self.assertEqual(favorite_author('', search('THe')), False)
    def test_title_and_author(self):
        self.assertEqual(title_and_author(search('fisk')), [('Fisk University', 'RussBot')])
        self.assertEqual(title_and_author(search(' ')), [])
        self.assertEqual(title_and_author(search('doG')), [('Black dog (ghost)', 'Pegship'), ('Mexican dog-faced bat', 'Mack Johnson'), ('Dalmatian (dog)', 'Mr Jake'), ('Guide dog', 'Jack Johnson'), ('Sun dog', 'Mr Jake')])
        self.assertEqual(title_and_author(search('canadIAN')), [('List of Canadian musicians', 'Jack Johnson'), ('2009 in music', 'RussBot'), ('Lights (musician)', 'Burna Boy'), ('Will Johnson (soccer)', 'Burna Boy'), ('2007 in music', 'Bearcat'), ('2008 in music', 'Burna Boy')])
    def test_refine_search(self): 
        self.assertEqual(refine_search('UniverSITY', search('FIsk')), [['Fisk University', 'RussBot', 1263393671, 16246]])
        self.assertEqual(refine_search('  ', search('MUsic')), [])
        self.assertEqual(refine_search('FIsk', search('  ')), [])


    #####################
    # INTEGRATION TESTS #
    #####################

    @patch('builtins.input')
    def test_example_integration_test(self, input_mock):
        keyword = 'soccer'
        advanced_option = 1
        advanced_response = 3000
        output = get_print(input_mock, [keyword, advanced_option, advanced_response])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(advanced_response) + "\n\nHere are your articles: [['Spain national beach soccer team', 'jack johnson', 1233458894, 1526], ['Steven Cohen (soccer)', 'Mack Johnson', 1237669593, 2117]]\n"
        self.assertEqual(output, expected)

    @patch('builtins.input')
    def test_integration_test_2(self, input_mock):
        keyword = 'musiC'
        advanced_option = 2
        advanced_response = 3
        output = get_print(input_mock, [keyword, advanced_option, advanced_response])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(advanced_response) + "\n\nHere are your articles: [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['French pop music', 'Mack Johnson', 1172208041, 5569], ['1922 in music', 'Gary King', 1242717698, 11576]]\n"
        self.assertEqual(output, expected)       

    @patch('builtins.input')
    def test_integration_test_3(self, input_mock):
        keyword = 'fiSk'
        advanced_option = 3
        output = get_print(input_mock, [keyword, advanced_option])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "\nHere are your articles: ['Fisk University', 'RussBot', 1263393671, 16246]\n"
        self.assertEqual(output, expected)

    @patch('builtins.input')
    def test_integration_test_4(self, input_mock):
        keyword = 'Dog'
        advanced_option = 4
        advanced_response = 'mr JAKE'
        output = get_print(input_mock, [keyword, advanced_option, advanced_response])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(advanced_response) + "\n\nHere are your articles: [['Black dog (ghost)', 'Pegship', 1220471117, 14746], ['Mexican dog-faced bat', 'Mack Johnson', 1255316429, 1138], ['Dalmatian (dog)', 'Mr Jake', 1207793294, 26582], ['Guide dog', 'Jack Johnson', 1165601603, 7339], ['Sun dog', 'Mr Jake', 1208969289, 18050]]\nYour favorite author is in the returned articles!\n"
        self.assertEqual(output, expected)

    @patch('builtins.input')
    def test_integration_test_5(self, input_mock):
        keyword = 'fisk'
        advanced_option = 5
        output = get_print(input_mock, [keyword, advanced_option])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "\nHere are your articles: [('Fisk University', 'RussBot')]\n"
        self.assertEqual(output, expected)

    @patch('builtins.input')
    def test_integration_test_6(self, input_mock):
        keyword = 'CanadIAN'
        advanced_option = 6
        advanced_response = 'MusiC'
        output = get_print(input_mock, [keyword, advanced_option, advanced_response])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(advanced_response) + "\n\nHere are your articles: [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['2009 in music', 'RussBot', 1235133583, 69451], ['Lights (musician)', 'Burna Boy', 1213914297, 5898], ['2007 in music', 'Bearcat', 1169248845, 45652], ['2008 in music', 'Burna Boy', 1217641857, 107605]]\n"
        self.assertEqual(output, expected)

    @patch('builtins.input')
    def test_integration_test_7(self, input_mock):
        keyword = 'soccer'
        advanced_option = 7
        output = get_print(input_mock, [keyword, advanced_option])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "\nHere are your articles: [['Spain national beach soccer team', 'jack johnson', 1233458894, 1526], ['Will Johnson (soccer)', 'Burna Boy', 1218489712, 3562], ['Steven Cohen (soccer)', 'Mack Johnson', 1237669593, 2117]]\n"
        self.assertEqual(output, expected)
         
    @patch('builtins.input')
    def test_integration_test_8(self, input_mock):
        keyword = 'soccer'
        advanced_option = 1
        advanced_response = 3000
        output = get_print(input_mock, [keyword, advanced_option, advanced_response])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(advanced_response) + "\n\nHere are your articles: [['Spain national beach soccer team', 'jack johnson', 1233458894, 1526], ['Steven Cohen (soccer)', 'Mack Johnson', 1237669593, 2117]]\n"
        self.assertEqual(output, expected)                                
# Write tests above this line. Do not remove.
if __name__ == "__main__":
    main()
